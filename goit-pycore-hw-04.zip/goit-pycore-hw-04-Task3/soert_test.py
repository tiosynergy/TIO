

numbers = [3, 1, 4, 1, 5]  # Исходный список
sorted_numbers = sorted(numbers)  # Сортируем и сохраняем в новую переменную
print(sorted_numbers)  # Вывод отсортированного списка
print(numbers)  # Вывод исходного списка (не изменился)

